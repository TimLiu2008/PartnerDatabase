/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fbla;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author Tim
 */
public class ActionButton extends JButton{
    
    public ActionButton(){
        //Creates the remove button
        setContentAreaFilled(false);
        setBorder(new EmptyBorder(3,3,3,3));
    }
}